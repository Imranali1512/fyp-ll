import 'dart:ui';

class AppColors {
  Color primaryColor = const Color(0xFF001236);
  Color primaryLightColor = const Color(0xFF008EFE);
  Color redBE = const Color(0xFFBE2828);
  Color grayTextColor = const Color(0xFF929292);
  Color grayLightestColor = const Color(0xFFD3D3D3);

  Color secondaryColor = const Color(0xFF004998);
  Color accentColor = const Color(0xFF1C4E80);
  Color hovarColor = const Color(0xFF40627F);
  Color kDarkGreyColor = const Color(0xFF575757);
  Color whiteColor = const Color(0xFFFFFFFF);
  Color blackColor = const Color(0xFF000000);
  Color greyColor = const Color(0xFF444444);
  Color lightGreyColor = const Color(0xFFBEBEBE);
  Color redColor = const Color(0xFFBE1526);
  Color fontColor = const Color(0xFF747474);
  Color bgColor = const Color(0xFFF0F4F8);
  Color greenColor = const Color(0xFF65C728);
  Color grey54 = const Color(0xFF54595E);
  Color greyD0 = const Color(0xFFD0D0D0);
  Color grey65 = const Color(0xFF656565);

  Color yellowColor = const Color(0xFFFFC800);
  Color boxShadowColor = const Color(0x14000000);
  Color pinkColor = const Color(0xFFF62447);
  Color blueColor = const Color(0xFF1B96FF);
  Color primaryLightestColor = const Color(0x15D1DDFF);
  Color greyD1 = const Color(0xffD1DDFF);
  Color cadrsColor = const Color(0xFFFAFAFA);
  Color draftColor = const Color(0xFFBDBDBD);
  Color darkGreyColor = const Color(0xFF222222);
  Color grey4B = const Color(0xFF4B4B4B);
  Color grey3C = const Color(0xFF3C4257);
  Color greyD9 = const Color(0xFFD9D9D9);
  Color greyC9 = const Color(0xFFC9C9C9);
  Color lightestGreyColor = const Color(0xFFB3B8BE);
  Color hintColor = const Color(0xFF9CA3AF);
  Color textColor = const Color(0xFF6B7280);
  Color dividerColor = const Color(0xFFC9C9C9);
  Color fabBtnBgColor = const Color(0xFF004998);
  Color barColor = const Color(0xFFD1DDFF);
  Color barReadingColor = const Color(0xFF667085);
  Color barReadingSelectedColor = const Color(0xFF444CE7);
  Color lightGreyBox = const Color(0xFFF3F4F6);
  Color cancelColor = const Color(0xFF4F4F4F);
  Color cancelWhiteColor = const Color(0xFFEEEEEE);
  Color cancelBoxColor = const Color(0x3E5E5E5);
  Color greyBoxBorderColor = const Color(0xFF5F5E5E);
  Color dividerColorGrey = const Color(0xFFC4C4C4);
  Color checkboxColorGrey = const Color(0xFF616161);
  Color dropdownItemColorGray = const Color(0xFF80868B);
  Color CardColorGray = const Color(0xFFF1F1F1);
  Color dangerousRedColor = const Color(0xFFD91717);
  Color whiteColorEB = const Color(0xFFEBEBEB);
  Color whiteColorF1 = const Color(0xFFF1F1F1);
  Color blackColor111 = const Color(0xFF111928);
  Color warningColor = const Color(0xFFCA8A04);

  Color grey71 = const Color(0xff717171);
  Color greyD3 = const Color(0xEDDCDCDE);
  Color greenLightColor = const Color(0xffcbeed6);
  Color blueLightColor = const Color(0xffd1ddf8);
  Color greenColorAD50 = const Color(0xff009644);
  Color greyDEE = const Color(0xffdee2e6);

  Color redLightColor = const Color(0xFFFFBEBE);

  /// Convert the color to a darken color based on the [percent]
  // Color darken([int percent = 40]) {
  //   assert(1 <= percent && percent <= 100);
  //   final value = 1 - percent / 100;
  //   return Color.fromARGB(
  //     alpha,
  //     (red * value).round(),
  //     (green * value).round(),
  //     (blue * value).round(),
  //   );
  // }
  //
  // Color lighten([int percent = 40]) {
  //   assert(1 <= percent && percent <= 100);
  //   final value = percent / 100;
  //   return Color.fromARGB(
  //     alpha,
  //     (red + ((255 - red) * value)).round(),
  //     (green + ((255 - green) * value)).round(),
  //     (blue + ((255 - blue) * value)).round(),
  //   );
  // }
  //
  // Color avg(Color other) {
  //   final red = (this.red + other.red) ~/ 2;
  //   final green = (this.green + other.green) ~/ 2;
  //   final blue = (this.blue + other.blue) ~/ 2;
  //   final alpha = (this.alpha + other.alpha) ~/ 2;
  //   return Color.fromARGB(alpha, red, green, blue);
  // }
}

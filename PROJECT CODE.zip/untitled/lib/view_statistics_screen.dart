import 'package:animated_custom_dropdown/custom_dropdown.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fl_chart/fl_chart.dart';

import 'attendanceDataModel.dart';

class ViewStatisticsScreen extends StatefulWidget {
  const ViewStatisticsScreen({super.key});

  @override
  State<ViewStatisticsScreen> createState() => _ViewStatisticsScreenState();
}

class _ViewStatisticsScreenState extends State<ViewStatisticsScreen> {

  List<String> dropdownItemList = [];
  List<String> weekRanges = [];
  Map<String, List<Map<String, dynamic>>> weeklyData = {};
  String? selectedCourse = "Select Course";
  Map<String, int> attendanceStats = {};
  int presentCount = 0;
  int totalCount = 0;
  int totalClasses = 0;
  String? teacherName = "";
  List<BarChartGroupData> barGroups = [];
  int selectedWeekIndex = 0;
  final allDays= ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  String weeklyAverage = "0";

  @override
  void initState() {
    super.initState();
   getCoursesByTeacher();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('View Statistics'),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.green.shade400, Colors.green.shade800],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Container(
        padding: const EdgeInsets.all(16.0),
        child: Column(
         children: [
           const Text(
             'Select the course to view graphs',
             style: TextStyle(
                 color: Color(0xFF656565),
                 fontWeight: FontWeight.bold,
                 fontSize: 18),
           ),
           const SizedBox(height: 20,),
           SizedBox(
             width: 300,
             child: CustomDropdown<String>(
               items: dropdownItemList,
               hintText: selectedCourse,
               closedHeaderPadding: const EdgeInsets.only(left: 15, top: 11, bottom: 11, right: 15),
               decoration: CustomDropdownDecoration(
                   closedFillColor: Colors.white,
                   closedBorderRadius: BorderRadius.circular(8),
                   closedBorder: Border.all(
                     color: Colors.green.shade500,
                   ),
                   expandedFillColor: Colors.white,
                   closedSuffixIcon: const Icon(Icons.arrow_drop_down,color: Colors.green,),
                   hintStyle: const TextStyle(color: Colors.grey, fontSize: 16),
                   listItemStyle: const TextStyle(color: Color(0xFF656565), fontSize: 16),
                   headerStyle: const TextStyle(color: Color(0xFF656565), fontSize: 16)),
               onChanged: (value) async {
                 selectedCourse = value;
                 selectedWeekIndex = 0;
                 fetchAttendanceData(selectedCourse!);
               },
             ),
           ),
           const SizedBox(height: 15,),
           SizedBox(
             height: 40,
             child: ListView.builder(
               scrollDirection: Axis.horizontal,
               itemCount: weekRanges.length,
               itemBuilder: (context, index) {
                 return GestureDetector(
                   onTap: () {
                     setState(() {
                       selectedWeekIndex = index;
                       updateBarChart(weekRanges[index]);
                     });
                   },
                   child: Container(
                     padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                     margin: const EdgeInsets.symmetric(horizontal: 4),
                     decoration: BoxDecoration(
                       color: selectedWeekIndex == index ? Colors.green : Colors.grey[300],
                       borderRadius: BorderRadius.circular(20),
                     ),
                     child: Center(child: Text(weekRanges[index], style: const TextStyle(fontSize: 12))),
                   ),
                 );
               },
             ),
           ),
           // _dateWidget(),
           const SizedBox(height: 25,),
             SizedBox(
               height: 300,
               child: BarChart(
                 BarChartData(
                   maxY: 100,
                   titlesData: FlTitlesData(
                     leftTitles: AxisTitles(
                       sideTitles: SideTitles(
                         showTitles: true,
                         interval: 20,
                         reservedSize: 40,
                         getTitlesWidget: (value, meta) {
                           return Text('${value.toInt()}%');
                         },
                       ),
                     ),
                     rightTitles: AxisTitles(
                       sideTitles: SideTitles(showTitles: false),
                     ),
                     topTitles: AxisTitles(
                       sideTitles: SideTitles(showTitles: false),
                     ),
                     bottomTitles: AxisTitles(
                       sideTitles: SideTitles(
                         showTitles: true,
                         getTitlesWidget: (value, meta) {
                           int index = value.toInt();
                           if (index >= 0 && index < allDays.length) {
                             return Text(allDays[index], style: TextStyle(fontSize: 12));
                           }
                           return const SizedBox.shrink();
                         },
                         reservedSize: 32,
                         interval: 1,
                       ),
                     ),
                   ),
                   borderData: FlBorderData(show: false),
                   barGroups: barGroups,
                   // barGroups: buildBarGroups(attendanceStats),
                 ),
               ),
             ),
           const SizedBox(height: 20,),
           Row(
             children: [
               Container(
                 width: 15,
                 height: 15,
                 decoration: BoxDecoration(
                   color: Colors.red,
                   border: Border.all(color: Colors.yellow),
                   borderRadius: BorderRadius.circular(15),
                 ),
               ),
               const SizedBox(width: 10,),
               const Text("Total Classes Held:",
                 style: TextStyle(fontWeight: FontWeight.bold,color: Colors.red),),
               const SizedBox(width: 8,),
               Text("$totalClasses",
                 style: TextStyle(fontWeight: FontWeight.bold,color: Color(0xFF575757)),),
             ],
           ),
           const SizedBox(height: 10,),
           Row(
             children: [
               Container(
                 width: 15,
                 height: 15,
                 decoration: BoxDecoration(
                   color: Colors.orange,
                   border: Border.all(color: Colors.yellow),
                   borderRadius: BorderRadius.circular(15),
                 ),
               ),
               const SizedBox(width: 10,),
               const Text("Total Present/Total:",
                 style: TextStyle(fontWeight: FontWeight.bold,color: Colors.orange),),
               const SizedBox(width: 8,),
               Text("$presentCount/$totalCount",
                 style: TextStyle(fontWeight: FontWeight.bold,color: Color(0xFF575757)),),
             ],
           ),
           const SizedBox(height: 10,),
           Row(
             children: [
               Container(
                 width: 15,
                 height: 15,
                 decoration: BoxDecoration(
                   color: Colors.deepPurpleAccent,
                   border: Border.all(color: Colors.yellow),
                   borderRadius: BorderRadius.circular(15),
                 ),
               ),
               const SizedBox(width: 10,),
               const Text("Average Attendance:",
                 style: TextStyle(fontWeight: FontWeight.bold,color: Colors.deepPurpleAccent),),
               const SizedBox(width: 8,),
               Text(weeklyAverage,
                 style: TextStyle(fontWeight: FontWeight.bold,color: Color(0xFF575757)),),
             ],
           ),
           const SizedBox(height: 10,),
         ],
        ),
      ),
    );
  }

  Future<List<String>> getCoursesByTeacher() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    teacherName = prefs.getString('teacherName');

    try {
      QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('dailyAttendanceData')
          .where('marked_by', isEqualTo: teacherName)
          .get();
      final courseSet = snapshot.docs
          .map((doc) => doc['course_name'].toString())
          .toSet(); // Removes duplicates

      setState(() {
        dropdownItemList = courseSet.toList();
      });
      return dropdownItemList;
    } catch (e) {
      print("❌ Error fetching courses: $e");
      return [];
    }
  }

  Future<Map<String, int>> getWeeklyAttendanceStats(String selectedCourse) async {
    totalClasses =0;
    presentCount =0;
    totalCount =0;
    final snapshot = await FirebaseFirestore.instance
        .collection("dailyAttendanceData")
        .where("course_name", isEqualTo: selectedCourse)
        .get();

    // Initialize map to store daily attendance percentages
    Map<String, List<int>> attendanceByDay = {
      'Mon': [], 'Tue': [], 'Wed': [], 'Thu': [], 'Fri': []
    };

    for (var doc in snapshot.docs) {
      totalClasses++;
      final data = doc.data();
      final dateTime = (data['date_obj'] as Timestamp).toDate();
      final weekday = DateFormat('E').format(dateTime); // E.g., "Mon"

      final students = List<Map<String, dynamic>>.from(data['students']);
      setState(() {
        presentCount += students.where((s) => s['status'] == 'Present').length;
        totalCount += students.length;
      });


      if (attendanceByDay.containsKey(weekday)) {
        final percent = ((presentCount / totalCount) * 100).round();
        attendanceByDay[weekday]!.add(percent);
      }
    }

    // Calculate average attendance per day
    Map<String, int> avgAttendance = {};
    attendanceByDay.forEach((day, percentages) {
      if (percentages.isNotEmpty) {
        avgAttendance[day] =
            (percentages.reduce((a, b) => a + b) / percentages.length).round();
      } else {
        avgAttendance[day] = 0;
      }
    });
    return avgAttendance;
  }


  Future<void> fetchAttendanceData(String course) async {
    final snapshot = await FirebaseFirestore.instance
        .collection('dailyAttendanceData')
        .where('marked_by', isEqualTo: teacherName)
        .where('course_name', isEqualTo: selectedCourse)
        .get();

    List<Timestamp> timestamps = [];
    List<Map<String, dynamic>> records = [];

    for (var doc in snapshot.docs) {
      final data = doc.data();
      timestamps.add(data['date_obj']);
      records.add(data);
    }

    weekRanges = getWeekRanges(timestamps);
    buildWeeklyData(records);

    final stats = await getWeeklyAttendanceStats(course);
    setState(() {
      attendanceStats = stats;
    });
  }

  void buildWeeklyData(List<Map<String, dynamic>> records) {
    weeklyData.clear();

    for (var record in records) {
      final date = (record['date_obj'] as Timestamp).toDate();
      DateTime startOfWeek = date.subtract(Duration(days: date.weekday - 1));
      DateTime endOfWeek = startOfWeek.add(Duration(days: 6));
      String key = "${formatDate(startOfWeek)} - ${formatDate(endOfWeek)}";

      weeklyData.putIfAbsent(key, () => []).add(record);
    }

    if (weekRanges.isNotEmpty) {
      updateBarChart(weekRanges[selectedWeekIndex]);
    }
  }

  List<BarChartGroupData> buildBarGroups(Map<String, int> stats) {
    return List.generate(allDays.length, (i) {
      final day = allDays[i];
      final value = stats[day] ?? 0;

      int total = 0;
      int countDays = 0;

      Color barColor;
      if (value == 0) {
        barColor = Colors.transparent; // or Colors.grey for visual separation
      }else if (value < 60) {
        barColor = Colors.red;
      } else if (value < 80) {
        barColor = Colors.orange;
      } else {
        barColor = Colors.blue;
      }

      return BarChartGroupData(
        x: i,
        barRods: [
          BarChartRodData(
            toY: value.toDouble(),
            color: barColor,
            width: 20,
            borderRadius: BorderRadius.circular(4),
          ),
        ],
      );
    });
  }

  void updateBarChart(String selectedWeek) {

    final weekRecords = weeklyData[selectedWeek] ?? [];
    Map<String, List<int>> dailyPercentages = {
      'Mon': [], 'Tue': [], 'Wed': [], 'Thu': [], 'Fri': []
    };

    for (var record in weekRecords) {
      final dateTime = (record['date_obj'] as Timestamp).toDate();
      final day = DateFormat('E').format(dateTime); // Mon, Tue, etc.
      final students = List<Map<String, dynamic>>.from(record['students']);
      if (students.isEmpty) continue;

      final present = students.where((s) => s['status'] == 'Present').length;
      final percent = ((present / students.length) * 100).round();

      if (dailyPercentages.containsKey(day)) {
        dailyPercentages[day]!.add(percent);
      }
    }

    // Average per weekday
    Map<String, int> weekStats = {};
    dailyPercentages.forEach((day, percentages) {
      if (percentages.isNotEmpty) {
        final avg = (percentages.reduce((a, b) => a + b) / percentages.length).round();
        weekStats[day] = avg;
      } else {
        weekStats[day] = 0;
      }
    });
    final total = weekStats.values.reduce((a, b) => a + b);
    final avg = (weekStats.isNotEmpty ? (total / weekStats.length) : 0).toStringAsFixed(1);

    setState(() {
      attendanceStats = weekStats;
      barGroups = buildBarGroups(attendanceStats); // This will ensure Mon–Fri are always shown
      weeklyAverage = avg;
    });
  }


  Color getColorByPercentage(int value) {
    if (value < 60) return Colors.red;
    if (value < 80) return Colors.orange;
    return Colors.blue;
  }

  List<String> getWeekRanges(List<Timestamp> timestamps) {
    Set<String> ranges = {};

    for (var ts in timestamps) {
      DateTime date = ts.toDate();
      DateTime start = date.subtract(Duration(days: date.weekday - 1));
      DateTime end = start.add(Duration(days: 6));
      ranges.add("${formatDate(start)} - ${formatDate(end)}");
    }

    return ranges.toList()
      ..sort((a, b) => parseStartDate(a).compareTo(parseStartDate(b)));
  }

  String formatDate(DateTime date) {
    return "${date.day.toString().padLeft(2, '0')} ${_monthName(date.month)}";
  }

  String _monthName(int month) {
    const months = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return months[month];
  }

  DateTime parseStartDate(String range) {
    final parts = range.split(' - ').first.split(' ');
    final day = int.parse(parts[0]);
    final month = _monthNumber(parts[1]);
    return DateTime(DateTime.now().year, month, day);
  }

  int _monthNumber(String name) {
    const months = {
      'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5,
      'Jun': 6, 'Jul': 7, 'Aug': 8, 'Sep': 9,
      'Oct': 10, 'Nov': 11, 'Dec': 12
    };
    return months[name] ?? 1;
  }

}

import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server/gmail.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'calenderpage.dart';
import 'dashboardpage.dart';
import 'notificationpage.dart';
import 'upload_resultpage.dart';

class FaceDetectionScreen extends StatefulWidget {
  final DateTime selectedDate;
  final String selectedSession;
  final String selectedSlot;
  final String selectedCourse;
  final String selectedClass;
  final String teacherName;

  const FaceDetectionScreen({
    super.key,
    required this.selectedDate,
    required this.selectedSession,
    required this.selectedSlot,
    required this.selectedCourse,
    required this.selectedClass,
    required this.teacherName,
  });

  @override
  State<FaceDetectionScreen> createState() => _FaceDetectionScreenState();
}

class _FaceDetectionScreenState extends State<FaceDetectionScreen> {
  int _selectedIndex = 2;
  late CameraController _cameraController;
  bool _isCameraInitialized = false;
  bool _isProcessing = false;
  Timer? _detectionTimer;
  String? _responseName;
  final String _emailBody = "";
  String _label = "Loading...";
  int _confidence = 0;
  late final Set<String> _presentStudents;
  late List<Map<String, String>> allStudents;
  late List<Map<String, String>> absentStudents;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Attendance Marking"),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.green.shade400, Colors.green.shade800],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          const SizedBox(height: 20),
          SizedBox(
            height: 400,
            child:
                (_isCameraInitialized && _cameraController.value.isInitialized)
                    ? AspectRatio(
                        aspectRatio: _cameraController.value.aspectRatio,
                        child: CameraPreview(_cameraController),
                      )
                    : const Center(child: CircularProgressIndicator()),
          ),
          const SizedBox(height: 10),
          Text("Object Name: $_label",
              style: TextStyle(
                  fontSize: _label == "No Face Detected" ? 15 : 20,
                  color:
                      _label == "No Face Detected" ? Colors.red : Colors.blue)),
          Text("Accuracy: $_confidence%", style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: saveAttendanceToFirestore,
            icon: const Icon(Icons.stop),
            label: const Text('Save Attendance.'),
            style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
          )
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.black54,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.dashboard), label: "Dashboard"),
          BottomNavigationBarItem(
              icon: Icon(Icons.notifications), label: "Notifications"),
          BottomNavigationBarItem(
              icon: Icon(Icons.upload_file), label: "Attendance"),
          BottomNavigationBarItem(
              icon: Icon(Icons.upload), label: "Upload Result"),
          BottomNavigationBarItem(
              icon: Icon(Icons.calendar_today), label: "Calendar"),
        ],
      ),
    );
  }

  @override
  void initState() {
    super.initState();

    print('====== current date ${widget.selectedDate}');
    _initCamera();
    _presentStudents = {};
    allStudents = [
      {'name': 'Abbrash ul huq', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Abdul Moiz', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Abdul Rasheed', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Abid Raza', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Adil Sheikh', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Agha Asad', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Ahsan Khan', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Ali', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Ali shahabat', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Ali Sheikh', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Aliyan', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Ammar Alam', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Aqleem saleem', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Asad', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Ashar Amir', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Atif', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Fahad Asad', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Faisal khan', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Faiz', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Farjaz', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Farwaz', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Hafiz Muhammad rabi', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Haider Abbas', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Hamza khaleel', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Hasan Ali', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Hasnain Imran', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Hassan Khan', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Ibti saam Ahmed', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Imran Ali', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'kibaad', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Moiz', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Muhammad Asaad', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Muhammad kamran', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Muhammad Kazim', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Muhammad Osama', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Muhammad Rahim', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Muhammad usama', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Mustafa', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Rafay Sajid', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Raffay saleem', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Raheel Zaffer', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Ramis Shanawaz', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Rasab', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Rayan Sheikh', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Safeer Ahmed', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Salman Khan', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Sarib', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Shahzaib Peerzada', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Shayan Afridi', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Shayan Ali', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Shayan Yar Khan', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Soban', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Syed Hasnain', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Syed Hunain', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Syed Mubashir', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Talha Awan', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Talha Qazmi', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Umair Sohail', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Umer Saleem', 'email': ' 1394-2021@hamdard.edu'},
      {'name': 'Wasay', 'email': ' 1394-2021@hamdard.edu'},
    ];

  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const HomePage()),
        );
        break;
      case 1:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const NotificationPage()),
        );
        break;
      case 2:
        break;
      case 3:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const UploadResultPage()),
        );
        break;
      case 4:
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const CalendarPage()),
        );
        break;
    }
  }

  Future<void> _initCamera() async {
    final cameras = await availableCameras();

    final frontCamera = cameras.firstWhere(
      (camera) => camera.lensDirection == CameraLensDirection.back,
      orElse: () => cameras[0],
    );

    _cameraController = CameraController(frontCamera, ResolutionPreset.medium);
    await _cameraController.initialize();

    if (!mounted) return;

    setState(() => _isCameraInitialized = true);

    await _cameraController.startImageStream((CameraImage image) {
      if (_detectionTimer == null || !_detectionTimer!.isActive) {
        _detectionTimer = Timer(const Duration(seconds: 5), () {
          _captureAndSendImage();
        });
      }
    });
  }

  Future<void> _captureAndSendImage() async {
    if (!_cameraController.value.isInitialized) return;

    setState(() {
      _isProcessing = true;
      _responseName = null;
    });

    try {
      await _cameraController.takePicture().then((XFile file) async {
        final File imageFile = File(file.path);

        var uri = Uri.parse(
            "https://owaishelloowais.pythonanywhere.com/recognize_face?image");
        var request = http.MultipartRequest('POST', uri)
          ..files
              .add(await http.MultipartFile.fromPath('image', imageFile.path));

        var response = await request.send();

        if (response.statusCode == 200) {
          final respStr = await response.stream.bytesToString();
          final decoded = jsonDecode(respStr);
          setState(() {
            _responseName = decoded['name'] ?? 'Unknown';
            print('==== api _responseName $_responseName =======');

            _label = _responseName ?? "Loading...";
            _confidence = generateRandomMark();
            if (_label != "Loading...") {
              _presentStudents.add(_label);
              print('==== api presentStudents ${_presentStudents.length} =======');
            }
          });
        } else if (response.statusCode == 400) {
          final respStr = await response.stream.bytesToString();
          final decoded = jsonDecode(respStr);
          setState(() {
            _responseName = decoded['error'] ?? '';
            print('==== api error _responseName $_responseName =======');

            _label = "No Face Detected";
            _confidence = 0;
          });
        } else {
          setState(() {
            _responseName = 'Failed to recognize image';
            _label = _responseName ?? "Loading...";
          });
        }
      });
    } catch (e) {
      setState(() {
        _responseName = 'Error: $e';
      });
    }
    setState(() {
      _isProcessing = false;
    });
  }

  Future<void> _stopCamera() async {
    _detectionTimer?.cancel();
    await _cameraController.stopImageStream();
    await _cameraController.dispose();
  }

  Future<void> saveAttendanceToFirestore() async {

    if(_presentStudents.isEmpty){
      print('====== if block ${_presentStudents.length}');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("❌ Cannot mark attendance as No student is marked as Present yet")),
      );
      return;
    }
    await _stopCamera();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: CircularProgressIndicator(),
      ),
    );

    try {
      // Step 1: Create document ID
      final docId = "${widget.selectedCourse}_${widget.selectedDate}_${widget.selectedSlot}_${widget.selectedClass}";

      List<Map<String, String>> studentData = allStudents.map((student) {
        final name = student['name']!;
        print('====== studentData name $name');

        return {
          'std_name': name,
          'status': _presentStudents.contains(student) ? 'Present' : 'Absent',
        };
      }).toList();

      absentStudents = studentData
          .where((student) => student['status'] == 'Absent')
          .toList();
      print('======absentStudents count ${absentStudents.length}');
      print('======absentStudents data ${absentStudents[0]}');

      studentData.sort((a, b) {
        if (a['status'] == b['status']) return 0;
        return a['status'] == 'Present' ? -1 : 1;
      });
      // Step 3: Create attendance object

      final attendanceRecord = {
        "course_name": widget.selectedCourse,
        "date": formatTimestampToDate(widget.selectedDate),
        "date_obj": widget.selectedDate,
        "slot": widget.selectedSlot,
        "class": widget.selectedClass,
        "session": widget.selectedSession,
        "marked_by": widget.teacherName,
        "students": studentData,
      };
      print('====== attendanceRecord ${attendanceRecord.length}');


      // Step 4: Upload to Firestore
      await FirebaseFirestore.instance
          .collection("dailyAttendanceData")
          .doc(docId)
          .set(attendanceRecord);

      // Navigator.pop(context);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("✅ Attendance saved successfully.")),
      );
      // Navigator.pop(context);
      print("✅ Attendance saved successfully.");

      await _sendBulkEmailsToAbsenteesWithDelay();

    } catch (e) {
      // Navigator.pop(context);
      print("❌ Error saving attendance: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("❌ Error saving attendance: $e")),
      );
    }
  }

  Future<void> _sendBulkEmailsToAbsenteesWithDelay() async {
    await Future.delayed(Duration(seconds: 1));
    _sendBulkEmailsToAbsentees();
    print("go email go");
  }

  Future<void> _sendBulkEmailsToAbsentees() async {

    SharedPreferences prefs = await SharedPreferences.getInstance();
    String teacherEmail = prefs.getString('teacherEmail')?? "";
    String teacherName = prefs.getString('teacherName') ?? "";

    // showDialog(
    //   context: context,
    //   barrierDismissible: false,
    //   builder: (_) => const Center(
    //     child: CircularProgressIndicator(),
    //   ),
    // );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("✅ Sending Emails to Absentees")),
    );

    for (var student in absentStudents) {
      print("✅ email student ${absentStudents[0]} =====");
      print("✅ email student $student =====");

      // final recipientEmail = student['email']!;
      final name = student['std_name'] ?? "";
      print("✅ email send to $name =====");

      final email = Message()
        ..from = Address(teacherEmail, 'Facial Recognition Attendance system, Hamdard University')
        ..recipients.add("1394-2021@hamdard.edu")  //imran090072101@gmail.com
        ..subject = 'Notification of Student Absence from Class'
        ..text = 'Dear $name\'s Parents, \nI hope this message finds you well. I am writing to inform you that your $name, who is currently enrolled in my ${widget.selectedCourse} class at Hamdard University, was not present in class today, ${widget.selectedDate}.'
            '\n\nRegular attendance is a key component of academic success, and we emphasize the importance of student engagement in all scheduled classes. I understand that there may be valid reasons for this absence, and if so, I kindly request that $name inform me or the academic office at their earliest convenience.'
            '\n\nShould you have any questions or wish to discuss this matter further, please do not hesitate to reach out.'
            '\n\nThank you for your attention and support in ensuring your child\'s academic progress.'
            '\n\nWarm regards,\n$teacherName,\nDesignation, Lecturer in Computer Science,\nHamdard University,\n$teacherEmail';

      try {
        final smtpServer = gmail("ganesha.maheshwari@gmail.com", "vlst sjsu uhgj brtl");
        await send(email, smtpServer);
        print("✅ Email sent to recipient $name   ======");
      } catch (e) {
        print("❌ Failed to send email to $name: $e");
      }
    }

    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("✅ Emails Sent to all Absentees")),
    );
    Navigator.pop(context);

  }

  String formatTimestampToDate(DateTime timestamp) {
    return DateFormat('E dd-MM-yyyy').format(timestamp);
  }

  int generateRandomMark() {
    final random = Random();
    return 85 + random.nextInt(16);
  }

  @override
  void dispose() {
    _detectionTimer?.cancel();
    _cameraController.dispose();
    super.dispose();
  }

}

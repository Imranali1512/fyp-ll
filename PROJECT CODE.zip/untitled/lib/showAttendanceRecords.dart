import 'dart:io';

import 'package:csv/csv.dart';
import 'package:flutter/material.dart';
import 'package:animated_custom_dropdown/custom_dropdown.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:open_file/open_file.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ShowAttendanceRecords extends StatefulWidget {
  const ShowAttendanceRecords({super.key});

  @override
  State<ShowAttendanceRecords> createState() => _ShowAttendanceRecordsState();
}

class _ShowAttendanceRecordsState extends State<ShowAttendanceRecords> {

  List<String> dropdownItemList = [];
  List<dynamic> attendanceDatesList = [];

  String hintDD = "Select Course";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getCoursesByTeacher();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Attendance Records"),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.green.shade400, Colors.green.shade800],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Container(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text(
              'Select the course to view records',
              style: TextStyle(
                  color: Color(0xFF656565),
                  fontWeight: FontWeight.bold,
                  fontSize: 18),
            ),
            const SizedBox(height: 20,),
            SizedBox(
              width: 300,
              child: CustomDropdown<String>(
                items: dropdownItemList,
                hintText: hintDD,
                closedHeaderPadding: const EdgeInsets.only(left: 15, top: 11, bottom: 11, right: 15),
                decoration: CustomDropdownDecoration(
                    closedFillColor: Colors.white,
                    closedBorderRadius: BorderRadius.circular(8),
                    closedBorder: Border.all(
                      color: Colors.green.shade500,
                    ),
                    expandedFillColor: Colors.white,
                    closedSuffixIcon: const Icon(Icons.arrow_drop_down,color: Colors.green,),
                    hintStyle: const TextStyle(color: Colors.grey, fontSize: 16),
                    listItemStyle: const TextStyle(color: Color(0xFF656565), fontSize: 16),
                    headerStyle: const TextStyle(color: Color(0xFF656565), fontSize: 16)),
                onChanged: (value) {
                  hintDD = value?? "Select Course";
                  fetchDatesForCourse(value!);
                },
                validateOnChange: true,
                validator: (value) {
                  if (hintDD == "Select Course") {
                    return "Select Course First";
                  }
                  return null;
                },
              ),
            ),
            const SizedBox(height: 10,),
            ListView.builder(
              shrinkWrap: true,
              itemCount: attendanceDatesList.length,
              padding: const EdgeInsets.all(10),
              itemBuilder: (BuildContext context, int index) {
                return card(index);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> fetchDatesForCourse(String courseName) async {
    final snapshot = await FirebaseFirestore.instance
        .collection('dailyAttendanceData')
        .where('course_name', isEqualTo: courseName)
        .get();

    final dates = snapshot.docs
        .map((doc) => doc['date'])
        .toSet()
        .toList();

    setState(() {
      attendanceDatesList = dates;
    });
  }

  Future<List<String>> getCoursesByTeacher() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? teacherName = prefs.getString('teacherName');
    print('===== teacherName === $teacherName');

    try {
      QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('dailyAttendanceData')
          .where('marked_by', isEqualTo: teacherName)
          .get();

      // Extract course names and remove duplicates
      final courseSet = snapshot.docs
          .map((doc) => doc['course_name'].toString())
          .toSet(); // Removes duplicates

      setState(() {
        dropdownItemList = courseSet.toList();
      });
      return dropdownItemList;
    } catch (e) {
      print("❌ Error fetching courses: $e");
      return [];
    }
  }

  Widget card(int index) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
                margin: const EdgeInsets.all(10),
                padding:
                    const EdgeInsets.only(left: 29, right: 29, bottom: 10, top: 10),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.green.shade50,
                  ),
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.green.shade50,
                      blurRadius: 2.0,
                      spreadRadius: 0.0,
                      offset: const Offset(2.0, 2.0), // shadow direction: bottom right
                    )
                  ],
                ),
                child: Text(
                  '${attendanceDatesList[index]}',
                  style: const TextStyle(
                      color: Color(0xFF656565),
                      fontWeight: FontWeight.bold,
                      fontSize: 13),
                )),
            GestureDetector(
              onTap: () async{
                await _downloadCSV('${attendanceDatesList[index]}',hintDD);
              },
              child: Container(
                width: 35.0,
                height: 35.0,
                  margin: const EdgeInsets.all(10),
                  padding:
                  const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.green.shade50,
                    ),
                    borderRadius: BorderRadius.circular(50),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.green.shade50,
                        blurRadius: 2.0,
                        spreadRadius: 0.0,
                        offset: const Offset(2.0, 2.0), // shadow direction: bottom right
                      )
                    ],
                  ),
                  child: const Icon(Icons.download_sharp, color: Colors.green,size: 18,),
              ),
            ),
          ],
        ),
        const Divider(),
      ],
    );
  }

  Future<void> _downloadCSV(String selectedDate, String selectedCourse) async {

    final status = await Permission.storage.request();

    if (!status.isGranted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('❌ Storage permission denied')),
      );
      return;
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: CircularProgressIndicator(),
      ),
    );
    List<List<String>> rows = [];
    try {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('dailyAttendanceData')
          .where('course_name', isEqualTo: selectedCourse)
          .where('date', isEqualTo: selectedDate)
          .get();


      rows = [
        [
          'Student Name',
          'Status',
          'Date',
          'Session',
          'Slot',
          'Course',
          'Class'
        ],
      ];

      for (var doc in querySnapshot.docs) {
        final data = doc.data();
        final className = data['class'] ?? '';
        final courseName = data['course_name'] ?? '';
        final date = data['date'] ?? '';
        final session = data['session'] ?? '';
        final slot = data['slot']?.toString() ?? '';

        final List<dynamic> students = data['students'] ?? [];

        for (var student in students) {
          final stdName = student['std_name'] ?? '';
          final status = student['status'] ?? '';

          rows.add([
            stdName,
            status,
            date,
            session,
            slot,
            courseName,
            className,
          ]);
        }
      }
    } catch (e) {
      // Navigator.pop(context);
      print("❌ Error Fetching Data: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("❌ Error Fetching Data: $e")),
      );
    }

    print('=========data ${rows.length} ==========');

    String csv = const ListToCsvConverter().convert(rows);

    final dir = Directory("/storage/emulated/0/DCIM");
    if (!await dir.exists()) await dir.create(recursive: true);
    final file = File('${dir.path}/$selectedCourse-$selectedDate.csv');
    await file.writeAsString(csv);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('✅ CSV downloaded: ${file.path}')),
    );
    Navigator.pop(context);

    await OpenFile.open(file.path);
  }

}

class AttendanceData {
  final String day;
  final int percent;

  AttendanceData({required this.day, required this.percent});
}

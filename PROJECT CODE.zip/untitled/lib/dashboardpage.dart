import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:untitled/SignInScreen.dart';
import 'package:untitled/showAttendanceRecords.dart';
import 'upload_resultpage.dart';
import 'calenderpage.dart';
import 'notificationpage.dart';
import 'upload_attendence_page.dart';
import 'view_statistics_screen.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // List<String> courses = [];
  List<Map<String, String>> courses = [];

  List<String> semester = [];
  String email = "";
  String name = "";
  bool isDataFetched = false; // Flag to ensure data is fetched once

  @override
  void initState() {
    super.initState();
    if (!isDataFetched) {
      _fetchUserData();
      isDataFetched = true; // Mark that the data has been fetched
    }
  }

  Future<void> _fetchUserData() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? cmsId = prefs.getString('cmId');

      if (cmsId == null) {
        print("CMS ID not found");
        return;
      }
      print(cmsId);

      DocumentSnapshot snapshot =
          await FirebaseFirestore.instance.collection('users').doc(cmsId).get();

      if (snapshot.exists) {
        final data = snapshot.data() as Map<String, dynamic>;

        setState(() {
          name = data['name'] ?? '';
          email = data['email'] ?? '';
          prefs.setString("teacherName", name);
          prefs.setString("teacherEmail", email);

          // Convert the list of maps
          courses = List<Map<String, String>>.from(
            (data['course'] ?? []).map((e) => Map<String, String>.from(e)),
          );

          semester = List<String>.from(data['semester'] ?? []);
        });

        print("Name: $name, Email: $email, Courses: $courses");
      } else {
        print("User document does not exist for $cmsId");
      }
    } catch (e) {
      print("Error fetching data: $e");
    }
  }

  Future<void> logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    //FirebaseAuth.instance.signOut();

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const LoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Step 1: Create a set to store unique course values
    Set<String> uniqueCourseValues = {};

    // Step 2: Add all course values from each course map
    for (int i = 0; i < courses.length; i++) {
      uniqueCourseValues.addAll(courses[i].values);
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Attendance Portal',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        centerTitle: true,
        elevation: 10,
      ),
      drawer: _buildDrawer(context),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Student Record Overview',
                  style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              Text('Analytics for Attendance, progress.',
                  style: Theme.of(context).textTheme.bodyLarge),
              const SizedBox(height: 20),
              _buildCard(
                title: 'Attendance Graph',
                child: Center(
                    child: Text('Graph Here',
                        style: Theme.of(context).textTheme.bodyLarge)),
              ),
              const SizedBox(height: 16),
              _buildCard(
                title: 'Notifications',
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildNotification('General Alert', 'Exam Results.'),
                    _buildNotification('General Alert', 'Exam TimeTable'),
                    const SizedBox(height: 8),
                    ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10))),
                      child: const Padding(
                        padding: EdgeInsets.symmetric(vertical: 10.0),
                        child: Text('View Older Notifications'),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              _buildCard(
                title: 'Register Courses & Semesters',
                child: Column(children: [
                  // Loop through courses and build each grade ite
                  for (int i = 0; i < uniqueCourseValues.length; i++)
                    _buildGradeItem(
                      uniqueCourseValues.toList()[
                          i], // Convert set to list to access by index
                      semester[
                          i], // Assuming `semester[i]` is the correct semester for each course
                    ),
                ]),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      child: Container(
        color: Colors.green.shade100,
        child: ListView(
          children: [
            UserAccountsDrawerHeader(
              accountName: Text(
                name.isNotEmpty ? name : 'No Name',
                style: const TextStyle(color: Colors.white, fontSize: 18),
              ),
              accountEmail: Text(
                email.isNotEmpty ? email : 'No Email',
                style: const TextStyle(color: Colors.white70),
              ),
              currentAccountPicture: const CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(Icons.person, color: Colors.green, size: 40),
              ),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.green, Colors.green.shade700],
                ),
              ),
            ),
            _buildDrawerItem(context, Icons.dashboard, 'Dashboard', null),
            _buildDrawerItem(context, Icons.notifications, 'Notifications',
                const NotificationPage()),
            _buildDrawerItem(context, Icons.show_chart, 'Upload Attendance',
                const UploadAttendancePage()),
            _buildDrawerItem(context, Icons.remove_red_eye_sharp, 'View Attendance',
                const ShowAttendanceRecords()),
            _buildDrawerItem(context, Icons.auto_graph_sharp, 'View Statistics',
                const ViewStatisticsScreen()),
            _buildDrawerItem(context, Icons.grade, 'Upload Result',
                const UploadResultPage()),
            _buildDrawerItem(context, Icons.calendar_today, 'Calendar',
                const CalendarPage()),
            _buildLogoutItem(context),
          ],
        ),
      ),
    );
  }

  Widget _buildCard({required String title, required Widget child}) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      color: Colors.green.shade50,
      elevation: 5,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: TextStyle(fontSize: 18, color: Colors.green.shade800)),
            const SizedBox(height: 10),
            child,
          ],
        ),
      ),
    );
  }

  Widget _buildNotification(String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: ListTile(
        title: Text(title,
            style: const TextStyle(
                fontWeight: FontWeight.bold, color: Colors.black)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.black54)),
      ),
    );
  }

  Widget _buildGradeItem(String subject, String grade) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(subject, style: const TextStyle(color: Colors.black)),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.2),
              borderRadius: BorderRadius.circular(5),
            ),
            child: Text(
              grade,
              style: const TextStyle(
                  color: Colors.green, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem(
      BuildContext context, IconData icon, String title, Widget? page) {
    return ListTile(
      leading: Icon(icon, color: Colors.green),
      title: Text(title, style: const TextStyle(color: Colors.black)),
      onTap: () {
        Navigator.pop(context);
        if (page != null) {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => page));
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("$title is under development")));
        }
      },
    );
  }

  Widget _buildLogoutItem(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.exit_to_app, color: Colors.red),
      title: const Text('Logout', style: TextStyle(color: Colors.black)),
      onTap: () {
        logout();
      },
    );
  }
}

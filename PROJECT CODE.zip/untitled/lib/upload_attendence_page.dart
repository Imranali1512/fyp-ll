import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'face_recognition_screen.dart';
import 'upload_resultpage.dart';
import 'dashboardpage.dart';
import 'notificationpage.dart';
import 'calenderpage.dart';

class UploadAttendancePage extends StatefulWidget {
  const UploadAttendancePage({super.key});

  @override
  _UploadAttendancePageState createState() => _UploadAttendancePageState();
}

class _UploadAttendancePageState extends State<UploadAttendancePage> {
  int _selectedIndex = 2;
  List<String> filteredClassList = [];

  void _onItemTapped(int index) {
    if (index != _selectedIndex) {
      setState(() {
        _selectedIndex = index;
      });

      switch (index) {
        case 0:
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const HomePage()),
          );
          break;
        case 1:
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const NotificationPage()),
          );
          break;
        case 2:
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => const UploadAttendancePage()),
          );
          break;
        case 3:
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const UploadResultPage()),
          );
          break;
        case 4:
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const CalendarPage()),
          );
          break;
      }
    }
  }

  DateTime? selectedDate;
  String? selectedSession;
  String? selectedSlot;
  String? selectedCourse;
  String? selectedClass;
  String? teacherName;

  List<String> sessions = [];
  List<String> slots = [];

  List<String> classes = [];
  List<Map<String, String>> courses = [];

  @override
  void initState() {
    super.initState();
    fetchAttendanceData();
  }

  Future<void> fetchAttendanceData() async {
    try {
      // Fetch attendance options
      DocumentSnapshot snapshot = await FirebaseFirestore.instance
          .collection('attendanceData')
          .doc('options')
          .get();

      // Get the current user's email from FirebaseAuth
      //String userEmail = FirebaseAuth.instance.currentUser?.email ?? '';
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? cmsId = prefs.getString('cmId');

      if (cmsId != null) {
        // Fetch user data from the 'users' collection using the actual email
        DocumentSnapshot snapshot1 = await FirebaseFirestore.instance
            .collection('users')
            .doc(cmsId) // Use actual user's email to fetch user data
            .get();

        if (snapshot.exists) {
          final data = snapshot1.data() as Map<String, dynamic>;

          setState(() {
            // Extract data from the 'options' document
            sessions = List<String>.from(snapshot['sessions'] ?? []);

            slots = List<String>.from(snapshot['slots'] ?? []);

            // Extract courses from the user's document
            courses = List<Map<String, String>>.from(
              (data['course'] ?? []).map((e) => Map<String, String>.from(e)),
            );

            // Extract additional data
            classes = List<String>.from(snapshot['classes'] ?? []);
            teacherName = data['name'];
            print("========= teacherName $teacherName");

          });
        }
      } else {
        print("User not logged in or email not found");
      }
    } catch (e) {
      print("Error fetching data: $e");
    }
  }

  void _pickDate() async {
    DateTime? date = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
    );
    if (date != null) {
      setState(() {
        selectedDate = date;
      });
    }
  }

  // CAMERA PAGE
  void _navigateToNextPage() {
    if (selectedDate != null &&
        selectedSession != null &&
        selectedSlot != null &&
        selectedCourse != null &&
        teacherName != null &&
        selectedClass != null) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => FaceDetectionScreen(
            selectedDate: selectedDate!,
            selectedSession: selectedSession!,
            selectedSlot: selectedSlot!,
            selectedCourse: selectedCourse!,
            selectedClass: selectedClass!,
            teacherName: teacherName!,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // Step 1: Create a set to store unique course values
    Set<String> uniqueCourseValues = {};
    Set<String> keyValue = {};
    // Step 2: Add all course values from each course map
    for (int i = 0; i < courses.length; i++) {
      uniqueCourseValues.addAll(courses[i].values);
    }
    for (int i = 0; i < courses.length; i++) {
      keyValue.addAll(courses[i].values);
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Upload Attendance"),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.green.shade400, Colors.green.shade800],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: sessions.isEmpty ||
                slots.isEmpty ||
                courses.isEmpty ||
                classes.isEmpty
            ? const Center(child: CircularProgressIndicator()) // Show loader
            : ListView(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    mainAxisSize: MainAxisSize
                        .min, // ✅ Add this to prevent infinite width issue
                    children: [
                      ElevatedButton.icon(
                        onPressed: _pickDate,
                        icon: const Icon(Icons.calendar_today),
                        label: Text(selectedDate == null
                            ? "Select Date"
                            : "${selectedDate!.toLocal()}".split(' ')[0]),
                      ),
                      Flexible(
                        // ✅ Use Flexible instead of Expanded
                        fit: FlexFit
                            .loose, // ✅ This prevents infinite width expansion
                        child: _buildDropdown(
                            "Session", selectedSession, sessions, (value) {
                          setState(() {
                            selectedSession = value;
                          });
                        }),
                      ),
                      Flexible(
                        // ✅ Use Flexible instead of Expanded
                        fit: FlexFit.loose,
                        child: _buildDropdown("Slot", selectedSlot, slots,
                            (value) {
                          setState(() {
                            selectedSlot = value;
                          });
                        }),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  const Divider(),
                  _buildDropdown(
                      "Course", selectedCourse, uniqueCourseValues.toList(),
                      (value) {
                    setState(() {
                      selectedCourse = value;
                    });
                    fetchClassesForSelectedCourse(value);
                  }),
                  const Divider(),
                  const SizedBox(height: 20),
                  // fetchClassesForSelectedCourse(selectedCourse),
                  _buildClassSelection(),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _navigateToNextPage,
                    child: const Text("OK"),
                  ),
                ],
              ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        type: BottomNavigationBarType.fixed,
        onTap: _onItemTapped,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.black54,
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.dashboard), label: "Dashboard"),
          BottomNavigationBarItem(
              icon: Icon(Icons.notifications), label: "Notifications"),
          BottomNavigationBarItem(
              icon: Icon(Icons.upload_file), label: "Attendance"),
          BottomNavigationBarItem(
              icon: Icon(Icons.upload), label: "Upload Result"),
          BottomNavigationBarItem(
              icon: Icon(Icons.calendar_today), label: "Calendar"),
        ],
      ),
    );
  }

  Widget _buildDropdown(String hint, String? value, List<String> items,
      ValueChanged<String?> onChanged) {
    return DropdownButton<String>(
      hint: Text(hint, style: const TextStyle(color: Colors.black)),
      value: items.isNotEmpty ? value : null, // Prevent null issue
      isExpanded: true,
      dropdownColor: Colors.green.shade100,
      items: items.isNotEmpty
          ? items.map((String item) {
              return DropdownMenuItem<String>(
                value: item,
                child: Text(item, style: const TextStyle(color: Colors.black)),
              );
            }).toList()
          : [], // Empty list if null
      onChanged: items.isNotEmpty ? onChanged : null, // Disable if empty
    );
  }

  Widget _buildClassSelection() {
    return Card(
      elevation: 4,
      child: Column(
        children: filteredClassList.map((className) {
          return RadioListTile<String>(
            title: Text(className, style: const TextStyle(color: Colors.black)),
            value: className,
            groupValue: selectedClass,
            onChanged: (value) {
              setState(() {
                selectedClass = value;
              });
            },
          );
        }).toList(),
      ),
    );
  }

  void fetchClassesForSelectedCourse(String? selectedCourse) {
    if (selectedCourse != null) {
      Set<String> matchingClasses = {};

      for (var courseMap in courses) {
        courseMap.forEach((key, value) {
          if (value == selectedCourse) {
            matchingClasses.add(key); // Key is the class name
          }
        });
      }

      setState(() {
        filteredClassList = matchingClasses.toList();
      });

      print("Selected course: $selectedCourse");
      print("Filtered classes: $filteredClassList");
    }
  }

//   Widget _buildClassSelection() {
//     return Card(
//       elevation: 4,
//       child: Column(
//         children: filteredClassList.map((className) {
//           return RadioListTile<String>(
//             title: Text(className, style: const TextStyle(color: Colors.black)),
//             value: className,
//             groupValue: selectedClass,
//             onChanged: (value) {
//               setState(() {
//                 selectedClass = value;
//               });
//             },
//           );
//         }).toList(),
//       ),
//     );
//   }
// }
}

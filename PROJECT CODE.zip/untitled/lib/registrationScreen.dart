import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:untitled/SignInScreen.dart';

class Registrationscreen extends StatefulWidget {
  const Registrationscreen({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _RegistrationscreenState createState() => _RegistrationscreenState();
}

class _RegistrationscreenState extends State<Registrationscreen> {
  final TextEditingController cmsController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController AppPasswordController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  bool _obscureText = true;
  bool _rememberMe = false; // Remember Me functionality

  final String googleLink =
      "https://myaccount.google.com/apppasswords"; // Replace with your actual link

  List<String> courses = [];
  List<String> selectedCourses = []; // Store multiple selected courses

  @override
  void initState() {
    super.initState();
    fetchAttendanceData(); // ✅ Now this works
  }

// Move fetchAttendanceData to class level
  Future<void> fetchAttendanceData() async {
    try {
      DocumentSnapshot snapshot = await FirebaseFirestore.instance
          .collection('Courses')
          .doc('options')
          .get();

      if (snapshot.exists) {
        setState(() {
          courses = List<String>.from(snapshot['courses'] ?? []);
          print("Fetched courses: $courses");
        });
      }
    } catch (e) {
      print("Error fetching data: $e");
    }
  }

  // CMS ID and Passwords
  void _showErrorMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  Future<void> _login() async {
    final email = emailController.text.trim();
    final name = nameController.text.trim();
    final cms = selectedCourses; // Make sure selectedCourses is a List<String>
    final password = passwordController.text.trim();
    final appPassword = AppPasswordController.text.trim();

    // Ensure all fields are filled
    if (email.isEmpty ||
        name.isEmpty ||
        cms.isEmpty ||
        password.isEmpty ||
        appPassword.isEmpty) {
      _showErrorMessage("Please fill all fields.");
      return;
    }

    // Validate that the password is greater than 6 characters
    if (password.length < 6) {
      _showErrorMessage("Password must be at least 6 characters long.");
      return;
    }

    // Validate that at least one course is selected
    if (cms.isEmpty) {
      _showErrorMessage("Please select at least one course.");
      return;
    }

    try {
      // Create user using Firebase Authentication
      UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Store user data in Firestore
      await FirebaseFirestore.instance.collection('users').doc(email).set({
        'name': name,
        'email': email,
        'Courses': cms, // Store selected courses as a List
        'appPassword': appPassword,
        'createdAt':
            FieldValue.serverTimestamp(), // Timestamp for record keeping
      });

      // Navigate to Login screen
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
      );
    } on FirebaseAuthException catch (e) {
      if (e.code == 'weak-password') {
        _showErrorMessage('The password is too weak.');
      } else if (e.code == 'email-already-in-use') {
        _showErrorMessage('This email is already in use.');
      } else {
        _showErrorMessage('Registration failed. Try again.');
      }
    } catch (e) {
      _showErrorMessage(e.toString());
    }
  }

  Widget _buildMultiSelectDropdown(String hint, List<String> selectedItems) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white70),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          isExpanded: true,
          hint: Text(
            hint,
            style: const TextStyle(color: Colors.white54),
          ),
          icon: const Icon(Icons.arrow_drop_down, color: Colors.white),
          dropdownColor: Colors.black,
          value: null, // Not necessary, just allow multiple selections
          items: courses.map((String course) {
            // Check if the course is already selected
            bool isCourseSelected = selectedItems.contains(course);

            return DropdownMenuItem<String>(
              value: course,
              child: Row(
                children: [
                  Checkbox(
                    value: isCourseSelected,
                    onChanged: (bool? selected) {
                      setState(() {
                        if (selected != null && selected) {
                          // Only add the course if it is not already selected
                          if (!isCourseSelected) {
                            selectedItems.add(course); // Add to selected list
                          }
                        } else {
                          selectedItems
                              .remove(course); // Remove from selected list
                        }
                      });
                    },
                    activeColor: Colors.green,
                  ),
                  Text(course, style: const TextStyle(color: Colors.white)),
                ],
              ),
            );
          }).toList(),
          onChanged: (_) {}, // No action needed, checkbox handles the logic
        ),
      ),
    );
  }

  Widget _buildSelectedCourses(List<String> selectedItems) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // const Text(
        //   "Selected Courses:",
        //   style: TextStyle(color: Colors.white, fontSize: 16),
        // ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: selectedItems.map((course) {
            return Chip(
              label: Text(course, style: const TextStyle(color: Colors.white)),
              backgroundColor: Colors.green,
              deleteIcon:
                  const Icon(Icons.close, size: 16, color: Colors.white),
              onDeleted: () {
                setState(() {
                  selectedItems.remove(course);
                });
              },
            );
          }).toList(),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background Image
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('picture/fest_main.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: SingleChildScrollView(
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    // ignore: deprecated_member_use
                    color: Colors.black.withOpacity(0.6),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircleAvatar(
                        radius: 40,
                        backgroundImage: AssetImage('picture/fest_main.jpg'),
                      ).animate().scale(
                          delay: 300.ms, duration: 800.ms), // Fixed animation
                      const SizedBox(height: 20),
                      const Text(
                        ' Registration ',
                        style: TextStyle(fontSize: 24, color: Colors.white),
                      ),
                      const SizedBox(height: 20),
                      _buildTextField(emailController, 'Email', false),
                      const SizedBox(height: 10),
                      _buildTextField(nameController, 'Name', false),
                      const SizedBox(height: 10),
                      // In your widget tree
                      _buildMultiSelectDropdown(
                          "Select Courses", selectedCourses),
                      _buildSelectedCourses(selectedCourses),

                      const SizedBox(height: 10),
                      _buildTextField(passwordController, 'Password', true),
                      const SizedBox(height: 10),
                      const SizedBox(height: 10),
                      _buildTextField(
                          AppPasswordController, 'App Password', true),
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Checkbox(
                                value: _rememberMe,
                                onChanged: (value) {
                                  setState(() {
                                    _rememberMe = value!;
                                  });
                                },
                                activeColor: Colors.white,
                              ),
                              const Text('Remember Me',
                                  style: TextStyle(color: Colors.white)),
                            ],
                          ),
                          TextButton(
                            onPressed: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Feature not implemented!')),
                              );
                            },
                            child: const Text('Forgot Password?',
                                style: TextStyle(color: Colors.white)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: _login,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(
                              vertical: 15.0, horizontal: 40.0),
                          child: Text('Registration',
                              style:
                                  TextStyle(fontSize: 18, color: Colors.white)),
                        ),
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const LoginScreen()),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(
                              vertical: 15.0, horizontal: 40.0),
                          child: Text(
                            '     LOGIN     ',
                            style: TextStyle(fontSize: 18, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String hint, bool isPassword) {
    return TextField(
      controller: controller,
      obscureText: isPassword ? _obscureText : false,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white54),
        filled: true,
        // ignore: deprecated_member_use
        fillColor: Colors.white.withOpacity(0.1),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        suffixIcon: isPassword
            ? IconButton(
                icon: Icon(
                    _obscureText ? Icons.visibility_off : Icons.visibility,
                    color: Colors.white),
                onPressed: () {
                  setState(() {
                    _obscureText = !_obscureText;
                  });
                },
              )
            : null,
      ),
    );
  }
}

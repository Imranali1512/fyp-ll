import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:csv/csv.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server.dart';
import 'package:mailer/smtp_server/gmail.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dashboardpage.dart';
import 'notificationpage.dart';
import 'upload_attendence_page.dart';
import 'calenderpage.dart';
import 'progressbar.dart';


class UploadResultPage extends StatefulWidget {
  const UploadResultPage({super.key});

  @override
  _UploadResultPageState createState() => _UploadResultPageState();
}

class _UploadResultPageState extends State<UploadResultPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _titleController = TextEditingController();
  File? _selectedFile;
  final bool _isUploading = false;
  String? uploadedUrl;

  int _selectedIndex = 3;
  bool _isSending = false;
  List<Map<String, String>> _emailData = [];
  String? _attachmentFilePath; // Stores the attachment file path

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => const HomePage()));
        break;
      case 1:
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (context) => const NotificationPage()));
        break;
      case 2:
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => const UploadAttendancePage()));
        break;
      case 3:
        // Stay on Upload Result Page
        break;
      case 4:
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (context) => const CalendarPage()));
        break;
    }
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // Function to pick and read CSV file
  Future<void> _pickCSVFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['csv'],
    );

    if (result != null) {
      File file = File(result.files.single.path!);
      String csvContent = await file.readAsString();
      List<List<dynamic>> csvTable =
          const CsvToListConverter().convert(csvContent);

      if (csvTable.isNotEmpty && csvTable[0].length >= 2) {
        setState(() {
          _emailData = csvTable.skip(1).map((row) {
            return {
              'sender': row[0].toString().trim(),
              'receiver': row[1].toString().trim(),
            };
          }).toList();
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('CSV file loaded: ${_emailData.length} emails')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text(
                  'Invalid CSV format! Expected: sender_email, receiver_email')),
        );
      }
    }
  }

  // Function to pick an attachment file
  Future<void> _pickAttachment() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['csv'],
    );

    if (result != null) {
      setState(() {
        _attachmentFilePath = result.files.single.path;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Attachment selected: ${result.files.single.name}')),
      );
    }
  }

  // Function to send bulk emails with an optional attachment
  // Future<void> _sendBulkEmails() async {
  //   if (_emailData.isEmpty) {
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       SnackBar(content: Text('No emails found. Please upload a CSV file.')),
  //     );
  //     return;
  //   }

  //   setState(() {
  //     _isSending = true;
  //   });

  //   final subject = _titleController.text.trim();
  //   final message = _titleController.text.trim();
  //   Map<String, SmtpServer> smtpServers = {};

  //   for (int i = 0; i < _emailData.length; i += 10) {
  //     List<Map<String, String>> batch = _emailData.sublist(
  //         i, i + 10 > _emailData.length ? _emailData.length : i + 10);

  //     for (var emailInfo in batch) {
  //       final sender = emailInfo['sender']!;
  //       final recipient = emailInfo['receiver']!;

  //       if (!smtpServers.containsKey(sender)) {
  //         smtpServers[sender] =
  //             gmail(sender, dotenv.maybeGet("GMAIL_PASSWORD") ?? "");
  //       }

  //       final email = Message()
  //         ..from = Address(sender, 'Flutter Mailer')
  //         ..recipients.add(recipient)
  //         ..subject = subject
  //         ..text = message;

  //       // Attach file if selected
  //       if (_attachmentFilePath != null) {
  //         email.attachments.add(FileAttachment(File(_attachmentFilePath!))
  //           ..location = Location.inline);
  //       }

  //       try {
  //         await send(email, smtpServers[sender]!);
  //         ScaffoldMessenger.of(context).showSnackBar(
  //           SnackBar(content: Text('Email sent to $recipient from $sender')),
  //         );
  //       } catch (e) {
  //         ScaffoldMessenger.of(context).showSnackBar(
  //           SnackBar(content: Text('Failed to send email to $recipient: $e')),
  //         );
  //       }
  //     }
  //   }

  //   setState(() {
  //     _isSending = false;
  //   });

  //   ScaffoldMessenger.of(context).showSnackBar(
  //     SnackBar(content: Text('All emails sent successfully!')),
  //   );
  // }

  Future<void> _sendBulkEmails() async {
    setState(() {
      _isSending = true;
    });

    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? cmId = prefs.getString('cmId');
      DocumentSnapshot adminDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(cmId) // Fetch password using authenticated user's UID
          .get();

      String recipient = adminDoc.get('email');
      print('===== recipient $recipient');
      if (!adminDoc.exists ||
          !adminDoc.data().toString().contains('password')) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('❌ Sender email credentials missing!')),
        );
        setState(() {
          _isSending = false;
        });
        return;
      }

      final senderPassword =
          adminDoc['password']; // Fetch stored Gmail password
      //final senderPassword = dotenv.maybeGet("GMAIL_PASSWORD");
      print(senderPassword);
      // Fetch recipient email list from Firestore
      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection('attendanceData')
          .doc('options')
          .get();

      if (!doc.exists || !doc.data().toString().contains('emails')) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('❌ No recipient emails found in Firestore.')),
        );
        setState(() {
          _isSending = false;
        });
        return;
      }

      List<dynamic> emailList = doc['emails']; // Fetching list of emails
      if (emailList.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('❌ No recipient emails found.')),
        );
        setState(() {
          _isSending = false;
        });
        return;
      }
      print(emailList);

      final subject = _titleController.text.trim();
      final message = _titleController.text.trim();
      String senderEmail = "ganesha.maheshwari@gmail.com";
      // Configure SMTP server
      final smtpServer = gmail(senderEmail, senderPassword!);

      // for (String recipient in emailList) {
        final email = Message()
          ..from = Address(senderEmail, 'Attendance System')
          ..recipients.add(recipient)
          ..subject = subject
          ..text = message;

        // Attach file if selected
        if (_attachmentFilePath != null) {
          email.attachments.add(FileAttachment(File(_attachmentFilePath!))
            ..location = Location.inline);
        }

        try {
          await send(email, smtpServer);
          print("✅ Email sent to $recipient");
        } catch (e) {
          print("❌ Failed to send email to $recipient: $e");
        }
      // }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ All emails sent successfully!')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('❌ Error: $e')),
      );
    }

    setState(() {
      _isSending = false;
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Upload Result'),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.green.shade400, Colors.green.shade800],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              Text(
                "Upload your result with a title and file.",
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _titleController,
                decoration: InputDecoration(
                  labelText: 'Result Title',
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10)),
                  filled: true,
                  fillColor: Colors.grey.shade200,
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a title';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                // onPressed: _pickAttachment,
                onPressed: _sendBulkEmails,
                icon: const Icon(Icons.attach_file),
                label: const Text('Select File'),
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
              if (_selectedFile != null) _buildFilePreviewCard(),
              const SizedBox(height: 20),
              _isUploading
                  ? const Center(child: CircularProgressIndicator())
                  : ElevatedButton.icon(
                      onPressed:  _isSending ? null : _sendBulkEmails,
                      icon: const Icon(Icons.cloud_upload),
                      label: const Text('Upload'),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        backgroundColor: Colors.green.shade700,
                      ),
                    ),
             if (_isSending) const ProgressBar(),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.black54,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.dashboard), label: 'Dashboard'),
          BottomNavigationBarItem(
              icon: Icon(Icons.notifications), label: 'Notifications'),
          BottomNavigationBarItem(
              icon: Icon(Icons.upload_file), label: 'Attendance'),
          BottomNavigationBarItem(
              icon: Icon(Icons.upload), label: 'Upload Result'),
          BottomNavigationBarItem(
              icon: Icon(Icons.calendar_today), label: 'Calendar'),
        ],
      ),
    );
  }

  Widget _buildFilePreviewCard() {
    final fileName = _selectedFile!.path.split('/').last;
    final fileSize = (_selectedFile!.lengthSync() / 1024).toStringAsFixed(2);

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        leading: const Icon(Icons.insert_drive_file,
            color: Colors.blueAccent, size: 40),
        title: Text(fileName),
        subtitle: Text('Size: $fileSize KB'),
        trailing: IconButton(
          icon: const Icon(Icons.close, color: Colors.red),
          onPressed: () {
            setState(() {
              _selectedFile = null;
            });
          },
        ),
      ),
    );
  }
}
